clear
python .aevsms.py
